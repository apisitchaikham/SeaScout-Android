#!/usr/bin/env bash
set -euo pipefail
if ! command -v gradle >/dev/null 2>&1; then
  echo 'Gradle is required. Open this project in Android Studio or install Gradle 8.11.1.' >&2
  exit 1
fi
gradle --no-daemon :app:assembleDebug
printf '\nAPK: %s\n' "$(pwd)/app/build/outputs/apk/debug/app-debug.apk"
