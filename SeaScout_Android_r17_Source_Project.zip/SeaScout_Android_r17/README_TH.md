# Sea Scout r17 — Android WebView project

โปรเจกต์นี้บรรจุไฟล์ `SeaScout_Marine_NavAssist_r17_Content_URI_GPS.html` รุ่น r17 ไว้ในแอป Android โดยตรง และเปิดผ่าน origin HTTPS ภายใน WebView (`appassets.androidplatform.net`) เพื่อให้ Browser Geolocation ทำงานร่วมกับคำขอสิทธิ์ Location ของ Android ได้

## คุณสมบัติของตัวห่อ Android

- เปิดหน้า Sea Scout แบบเต็มจอในแอป ไม่ต้องเปิดผ่าน `content://` หรือแอป Files
- เปิด JavaScript และ local storage ที่หน้า HTML ใช้อยู่
- ขอสิทธิ์ GPS ของ Android เมื่อหน้าเว็บเรียก Geolocation API เป็นครั้งแรก
- รองรับทั้ง precise location และ approximate location ตามสิทธิ์ที่ผู้ใช้เลือก
- จำกัดสิทธิ์ Geolocation ให้เฉพาะ origin ของแอปที่ฝังมากับ APK
- ปิด file access/content access ของ WebView และไม่อนุญาต mixed content

## วิธีสร้าง APK

### Android Studio

1. เปิด Android Studio แล้วเลือก **Open** จากโฟลเดอร์ `SeaScout_Android_r17`
2. รอ Gradle Sync และติดตั้ง Android SDK Platform 35 หาก IDE แจ้งว่าขาด
3. เลือกเมนู **Build → Build Bundle(s) / APK(s) → Build APK(s)**
4. ไฟล์ติดตั้งจะอยู่ที่ `app/build/outputs/apk/debug/app-debug.apk`

### GitHub Actions

1. อัปโหลดโฟลเดอร์นี้ไปยัง repository ของคุณ โดยใช้ branch `main` หรือ `master`
2. เปิดแท็บ **Actions** แล้วเลือก **Build Sea Scout APK**
3. กด **Run workflow** หรือรอให้ build เริ่มจาก push
4. ดาวน์โหลด artifact ชื่อ `SeaScout-r17-Android-APK` แล้วแตก ZIP จะได้ `SeaScout-r17-debug.apk`

## การใช้งานครั้งแรกบนโทรศัพท์

1. ติดตั้ง APK และเปิด Sea Scout
2. เมื่อกดเริ่ม GPS ให้เลือก **อนุญาตขณะใช้แอป** และเลือกตำแหน่งที่แม่นยำ (Precise) หากต้องการความแม่นยำสูงสุด
3. เปิด Location/GPS ของระบบ Android และออกไปยังบริเวณที่รับสัญญาณได้
4. แอปยังต้องใช้อินเทอร์เน็ตสำหรับแผนที่, tile, ข้อมูลทะเล, พยากรณ์อากาศ และ API ภายนอก

## ข้อจำกัดสำคัญ

- โปรเจกต์นี้เป็น Android WebView wrapper ของ HTML r17 ไม่ได้เพิ่มข้อมูล bathymetry/ENC ใหม่ และไม่ได้ทำให้แผนที่มีข้อมูลลึกขึ้นโดยอัตโนมัติ
- NMEA ผ่าน Web Serial API และการต่ออุปกรณ์ USB/Serial อาจไม่รองรับใน Android WebView; การรับ GPS ในตัวเครื่องผ่าน Geolocation เป็นเส้นทางหลักของ APK รุ่นนี้
- ฟีเจอร์แผนที่/3D และข้อมูลสดบางส่วนต้องพึ่งพาอินเทอร์เน็ตและบริการภายนอก
- ห้ามใช้แอปนี้เป็นอุปกรณ์นำทางหลักหรือแทน official nautical chart / chartplotter / อุปกรณ์ความปลอดภัยทางทะเล

## Build configuration

- Application ID (debug): `com.seascout.marine.debug`
- Version: `1.17.0-debug` (versionCode 17)
- minSdk: 23 (Android 6.0)
- compileSdk / targetSdk: 35
- Java: 17
- AndroidX WebKit: 1.12.1
